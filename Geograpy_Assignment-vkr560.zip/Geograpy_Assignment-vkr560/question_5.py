import math

def Mario_Pizza(n,k):

    if k>n:
        return 0
    elif n==0 or n==k:
        return 1

    BIONOMIAL_N = math.factorial(n)
    BIONOMIAL_K = math.factorial(k) * (math.factorial(n - k))

    return BIONOMIAL_N/BIONOMIAL_K


print("Mario can make %d pizzas."%Mario_Pizza(10,3))


def Luigi_Pizza(n,k):
    if k > n:
        return 0
    elif n == 0 or n == k:
        return 1

    BIONOMIAL_N = math.factorial(n)
    BIONOMIAL_K = math.factorial(k) * (math.factorial(n - k))

    return BIONOMIAL_N / BIONOMIAL_K

print("Luigi can make %d pizzas."%Luigi_Pizza(9,4))


def Pizza_Winner(x,y):
    if x>y:
        return ("The winner is MARIO")
    else:
        return ("The winner is LUIGI")

print(Pizza_Winner(Mario_Pizza(10,3), Luigi_Pizza(9,4)))