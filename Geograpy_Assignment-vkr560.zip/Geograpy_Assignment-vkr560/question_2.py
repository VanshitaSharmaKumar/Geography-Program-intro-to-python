def palindrome(string):

    if string == string[::-1]:
        return "Is a palindrome"
    else:
        return "Is not a palindrome"


ALPHABET = "abcdefghijklmnopqrstuvwxyzyxwvutsrqponmlkjihgfedcba"

print("The following string:",palindrome(ALPHABET))
