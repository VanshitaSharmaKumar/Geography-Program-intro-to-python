#file name is geography_grades.txt

def sum_grades(line):
    if line =='':
        return

    final_result = line.split("_")
    student_names = final_result[0]

    average = [float(values) for values in final_result[-1].split(' ')]
    average_sum = sum(average) / len(average)
    print('{} has an average grade of {:.2}'.format(student_names, average_sum))


file_name =input("Enter name of file: ")
choosen_name = (open(file_name).read().split('\n'))
#print("The following grades are:\n", content)
#lines = choosen_name.splitlines()

for line in choosen_name:
    sum_grades(line)