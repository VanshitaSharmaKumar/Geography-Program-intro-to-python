def pyramid(rows):
    ALPHABET = "abcdefghijklmnopqrstuvwxyz"
    for i in range(rows, 0, -1):
        for j in range(i):
            print(' ', end='')
        for k in range(rows-i):
            print(ALPHABET[k], end='')
        for m in range(rows-i, -1, -1):
            print(ALPHABET[m], end='')
        print()

pyramid(15)

