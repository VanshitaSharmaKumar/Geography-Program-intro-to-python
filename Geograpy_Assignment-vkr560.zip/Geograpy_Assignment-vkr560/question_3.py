def palindrome(string):

    if string == string[::-1]:
        return "Is a palindrome"
    else:
        return "Is not a palindrome"


user_input = input("Enter any word to check if it is a palindrome: ")

print("The following string:",palindrome(user_input))

