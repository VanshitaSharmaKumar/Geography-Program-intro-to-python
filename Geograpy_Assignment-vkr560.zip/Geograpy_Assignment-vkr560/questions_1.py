def warning_message(x):
    print("NUCLEAR CORE UNSTABLE!!!")
    print("Quarantine is in effect.")
    print("Surrounding hamlets will be evacuated.")
    print("Anti-radiationsuits and iodine pills are mandatory.")


REPETITION_OF_WARNING = 0

while REPETITION_OF_WARNING!=3:
    REPETITION_OF_WARNING+= 1
    print(warning_message(REPETITION_OF_WARNING))
